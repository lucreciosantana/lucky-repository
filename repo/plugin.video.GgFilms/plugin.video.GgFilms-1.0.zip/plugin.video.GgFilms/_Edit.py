import xbmcaddon

MainBase = 'https://goo.gl/ucgqV8'
addon = xbmcaddon.Addon('plugin.video.GgFilms')